import os  
import subprocess  
import pandas as pd  
import glob  
import xml.etree.ElementTree as ET  
import time  
import shutil  
import pyzipper  # Imported for ZIP handling  
import tkinter as tk
from tkinter import ttk
from tkinter import simpledialog
from tkinter import Tk, Frame, Label, Entry, Button, Text, Scrollbar, END, filedialog, VERTICAL, messagebox 
import webview  
import os 
import webbrowser
import webview
from datetime import datetime

# Declare the label as global  
selected_directory_label = None  
status_label = None  # Also declare it global
view_report_button = None
ZIP_PASSWORD = 'f0rens!caW1nd0w$@rtifact@naIys!sTOOl'
 

def run_command(command):  
    try:  
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)  
        stdout, stderr = process.communicate()  # Wait for the command to complete  
        return process.returncode  
    except Exception as e:  
        print(f"Error running command {command}: {e}")  
        return None  

def unzip_plugins(zip_path, extract_to):  
    """Unzips the plugins with password."""  
    try:  
        with pyzipper.AESZipFile(zip_path, 'r') as zip_ref:  
            zip_ref.extractall(extract_to, pwd=ZIP_PASSWORD.encode('utf-8'))  
    except Exception as e:  
        print(f"Error unzipping {zip_path}: {e}")
    if not os.path.exists('output'):
        os.makedirs('output')        



def process_prefetch(directory):  
    
    output_path = os.path.join("output", "prefetch.csv")  
    try:  
        os.system(f'plugins\\prefetch.exe -d "{directory}\\Windows\\prefetch" --csv "{output_path}"')  
        return pd.read_csv(output_path)  # Adjust as needed  
    except Exception as e:  
        print_to_sidebar(f"Error processing Prefetch data: {e}")  
        return None  

def process_amcache(directory):  
    output_path = os.path.join("output", "amcache.csv")  
    try:  
        os.system(f'plugins\\amcache.exe -p "{directory}\\Windows\\appcompat\\Programs\\AmCache.hve" --csv "{output_path}"')  
        return pd.read_csv(output_path)  # Adjust as needed  
    except Exception as e:  
        print_to_sidebar(f"Error processing AmCache data: {e}")  
        return None  

def process_rb_cmd(directory):  
    recycle_bin_path = os.path.join(directory, "$Recycle.Bin")  
    output_path = os.path.join("output", "recyclebin.csv")  
    
    if not os.path.exists(recycle_bin_path):  
        print_to_sidebar("Error: $Recycle.Bin directory does not exist.")  
        return None  
    
    all_data = []  
    
    for root, dirs, files in os.walk(recycle_bin_path):  
        if root == recycle_bin_path:  
            continue  # Skip the root $Recycle.Bin itself  
        
        try:  
            os.system(f'plugins\\recyclebin.exe -d "{root}" --csv "temp_output.csv"')  
            if os.path.exists("temp_output.csv"):  
                df = pd.read_csv("temp_output.csv")  
                all_data.append(df)  
                os.remove("temp_output.csv")  
        except Exception as e:  
            print_to_sidebar("Error processing recycle bin data")  
    
    if all_data:  
        final_df = pd.concat(all_data, ignore_index=True)  
        final_df.to_csv(output_path, index=False)    
        print_to_sidebar(f"Recycle Bin results saved")        
        return final_df  
    else:  
        print_to_sidebar("Error: No valid Recycle Bin data found.")  
        return None  
      

def process_le_cmd(directory):  
    user_dirs = []  
    try:  
        user_dirs = [name for name in os.listdir(os.path.join(directory, "Users")) if os.path.isdir(os.path.join(directory, "Users", name))]  
    except FileNotFoundError:  
        print_to_sidebar(f"Directory not found: {os.path.join(directory, 'Users')}. Skipping user LNK processing.")  
        return {}  # Return an empty dictionary since no user directories can be processed  

    lnk_dataframes = {}  

    for user in user_dirs:  
        user_lnk_path = os.path.join(directory, "Users", user, "AppData", "Roaming", "Microsoft", "Windows", "Recent")  
        output_path = os.path.join("output", f"LNKFiles_{user}.csv")  # Create a unique output path for each user  

        if not os.path.exists(user_lnk_path):  
            print_to_sidebar(f"Skipping user {user}: LNK does not exist.")  
            continue  # Skip this user and move to the next one  

        try:  
            # Run the command to generate the CSV for the specific user  
            os.system(f'plugins\\LNKFiles.exe -d "{user_lnk_path}" --csv "{output_path}"')  
            lnk_dataframes[user] = pd.read_csv(output_path)  # Read the user-specific CSV  
        except Exception as e:  
            print_to_sidebar(f"Error processing LNK files for user {user}: {e}")  

    return lnk_dataframes  

def process_powershell_history(directory):  
    try:
        users = [d for d in os.listdir(os.path.join(directory, "Users")) if os.path.isdir(os.path.join(directory, "Users", d))]  
    except FileNotFoundError:  
        print_to_sidebar(f"Directory not found: {os.path.join(directory, 'Users')}. Skipping user LNK processing.")  
        return {}    
    results = {}  

    for user in users:  
        history_file = os.path.join(directory, "Users", user, "AppData", "Roaming", "Microsoft", "Windows", "PowerShell", "PSReadline", "ConsoleHost_history.txt")  
        if os.path.exists(history_file):  
            try:  
                with open(history_file, 'r') as file:
                    history = file.readlines()  
                print_to_sidebar(f"PowerShell history retrieved for user: {user}")  
                # Convert history list to DataFrame  
                results[user] = pd.DataFrame(history, columns=["Command"])  # Consider renaming "Command" to a more descriptive title if needed  
            except Exception as e:  
                print_to_sidebar(f"Error reading history file for user {user}: {e}")  
        else:  
            print_to_sidebar(f"No PowerShell history found for user: {user}")  

    return results   

def process_scheduled_tasks(directory):  
    """  
    Processes scheduled task files (without extensions) in the given directory.  
    Extracts Name, Description, URI, Start Boundary, Command, and Arguments.  
    """  
    tasks_data = []  
    try:    
        tasks_path = os.path.join(directory, "Windows", "System32", "Tasks")  # Assuming tasks are in a 'Tasks' folder  
    except FileNotFoundError:  
        print_to_sidebar(f"Directory not found: {os.path.join(directory, 'Users')}. Skipping user LNK processing.")  
        return {}
    if not os.path.exists(tasks_path):  
        print_to_sidebar(f"Scheduled Tasks directory not found: {tasks_path}")  
        return None  

    for file in os.listdir(tasks_path):  
        file_path = os.path.join(tasks_path, file)  

        # Skip if it's not a file or doesn't have a valid name (tasks have no extensions)  
        if not os.path.isfile(file_path):  
            continue  

        try:  
            # Parse the XML file  
            tree = ET.parse(file_path)  
            root = tree.getroot()  

            # Extract fields  
            name = file  # File name as task name  
            description = root.find(".//{http://schemas.microsoft.com/windows/2004/02/mit/task}Description")  
            uri = root.find(".//{http://schemas.microsoft.com/windows/2004/02/mit/task}URI")  
            start_boundary = root.find(".//{http://schemas.microsoft.com/windows/2004/02/mit/task}StartBoundary")  
            command = root.find(".//{http://schemas.microsoft.com/windows/2004/02/mit/task}Command")  
            arguments = root.find(".//{http://schemas.microsoft.com/windows/2004/02/mit/task}Arguments")  

            # Safely get the text content, fallback to 'N/A' if the element is missing  
            tasks_data.append({  
                "Task Name": name,  
                "Description": description.text if description is not None else "N/A",  
                "URI": uri.text if uri is not None else "N/A",  
                "Start Boundary": start_boundary.text if start_boundary is not None else "N/A",  
                "Command": command.text if command is not None else "N/A",  
                "Arguments": arguments.text if arguments is not None else "N/A"  
            })  

        except ET.ParseError:  
            print_to_sidebar(f"Error parsing XML in file: {file_path}")  
        except Exception as e:  
            print_to_sidebar(f"Unexpected error while processing {file_path}: {e}")  

    # Convert to DataFrame for easier handling in the report  
    if tasks_data:  
        return pd.DataFrame(tasks_data)  
    else:  
        print_to_sidebar("No valid scheduled tasks found.")  
        return None                
  
# Global variables for widgets that need to be accessed in multiple functions
sidebar_frame = None
cmd_output_text = None
case_listbox = None
status_label = None
view_report_button = None
root = None

# Create the main GUI window and populate it
def create_gui():
    global sidebar_frame, result_frame, cmd_output_text, case_listbox, directory_entry, case_name_entry, view_report_button, status_label

    # Initialize main window
    root = tk.Tk()
    root.title("Forensica Windows - Artifact Analysis Tool")
    root.geometry("1200x800")  # Start with a larger window
    root.state('zoomed')  # Maximize the window
    root.resizable(True, True)

    # Main frame with top padding to push content down
    main_frame = tk.Frame(root)
    main_frame.pack(expand=True, fill='both')

    # Left Sidebar frame (covering left half)
    sidebar_frame = tk.Frame(main_frame, width=800, bg="#f1f1f1")
    sidebar_frame.pack(side=tk.LEFT, fill=tk.Y, padx=20)

    # Title Label (Tool name centered at the top)
    title_label = tk.Label(sidebar_frame, text="Forensica Windows", font=("Helvetica", 40, "bold"))
    title_label.pack(pady=(20, 0), anchor='w')  # Title centered at the top with padding only at the top

    # Subtitle label (Centered below the title)
    subtitle_label = tk.Label(sidebar_frame, text="Artifact Analysis Tool", font=("Helvetica", 20))
    subtitle_label.pack(pady=(10, 10), anchor='w')  # Subtitle centered below the title with padding

    # Case Name Entry
    case_name_label = tk.Label(sidebar_frame, text="Case Name:", font=("Helvetica", 12))
    case_name_label.pack(pady=(130,0), anchor='w')
    case_name_entry = tk.Entry(sidebar_frame, width=40, font=("Helvetica", 12))
    case_name_entry.pack(pady=5, anchor='w')

    # Browse Directory Entry
    directory_label = tk.Label(sidebar_frame, text="Directory:", font=("Helvetica", 12))
    directory_label.pack(pady=5, anchor='w')
    directory_entry = tk.Entry(sidebar_frame, width=40, font=("Helvetica", 12))
    directory_entry.pack(pady=5, anchor='w')
    browse_button = tk.Button(sidebar_frame, text="Browse", command=lambda: browse_directory(directory_entry), font=("Helvetica", 12))
    browse_button.pack(pady=5, anchor='w')

    # Start Analysis Button
    start_analysis_button = tk.Button(sidebar_frame, text="Start Analysis", command=lambda: start_analysis(directory_entry.get(), case_name_entry.get(), view_report_button, start_analysis_button), width=20, font=("Helvetica", 12))  
    start_analysis_button.pack(pady=10, anchor='w')

    # View Report Button (Initially hidden)
    view_report_button = tk.Button(sidebar_frame, text="View Report", command=view_report, width=20, font=("Helvetica", 12))
    view_report_button.pack(pady=10, anchor='w')
    view_report_button.pack_forget()

    # Right Result display frame (covering right half)
    result_frame = tk.Frame(main_frame)
    result_frame.pack(side='right', expand=True, fill='both', padx=20)

    # Recent Cases Section (Right side - Top, spanning full width)
    recent_cases_label = tk.Label(result_frame, text="Recent Cases", font=("Helvetica", 16, "bold"))
    recent_cases_label.pack(pady=(60,0), anchor='center')

    case_listbox = tk.Listbox(result_frame, height=10, width=50, font=("Helvetica", 12))
    case_listbox.pack(padx=10, pady=10)
    open_button = tk.Button(result_frame, text="Open", command=open_selected_case_from_list, font=("Helvetica", 12))
    open_button.pack(pady=5)

    # Debug console for analysis logs (Right side - Bottom, below the recent cases)
    cmd_output_text = tk.Text(result_frame, height=15, width=50, wrap=tk.WORD, state=tk.NORMAL, font=("Helvetica", 12))
    cmd_output_text.pack(padx=10, pady=10)

    # Scrollbar for Text widget (cmd_output_text)
    scrollbar = tk.Scrollbar(result_frame, command=cmd_output_text.yview)
    cmd_output_text.config(yscrollcommand=scrollbar.set)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # Status Label (to show status messages)
    status_label = tk.Label(root, text="", fg="green", font=("Helvetica", 12))
    status_label.pack(pady=10)

    # Call the function to populate the case list
    populate_case_list()

    root.mainloop()
    
def browse_directory(entry_field):  
    directory = filedialog.askdirectory()  
    if directory:  
        entry_field.delete(0, 'end')  
        entry_field.insert(0, directory)  

def start_analysis(directory_path, case_name, view_report_button, start_analysis_button):  
    
    print_to_sidebar(f"{directory_path} selected")
    print_to_sidebar("Analysis in progress ...")
    start_analysis_button.config(state=tk.DISABLED)  # Disable button  
    if directory_path and case_name:
        status_label.config(text=f"Starting analysis on {directory_path} with case name '{case_name}'...")
        results = perform_analysis(directory_path, case_name)  # Perform the analysis
        if results:  # If results are valid
            create_html_report(results, directory_path, case_name)  # Save the report with the case name
            status_label.config(text=f"Analysis completed. Report saved as '{case_name}.html'.")
            # Ensure the View Report button appears after analysis
            view_report_button.pack(pady=5)  # Ensure it is packed
        else:
            status_label.config(text="Analysis failed. Please check the logs for more details.")
    else:
        status_label.config(text="Error: No directory or case name provided.")  
        
  
    start_analysis_button.config(state=tk.NORMAL)  # Re-enable button

def perform_analysis(directory, case_name):  
    results = {}  
    zip_path = "plugins.zip"  # Point to your existing password-protected ZIP file  
    if not os.path.exists("plugins"):  
        if not unzip_plugins(zip_path, "plugins"):  
            return None  # Return None if unzipping fails  

    error_messages = []  # Collect error messages here    
    results = {  
            'RecycleBin_Data': None,  
            'AmCache_Data': None,  
            'Prefetch Files Details': None,  
            'LNK_Files_Details': None,  
            'PowerShell_History': None,  
            'Scheduled_Tasks': None,  
            'Log_Analysis': None  
        }  


    try:  
        results['RecycleBin_Data'] = process_rb_cmd(directory)  
    except Exception as e:  
        error_messages.append(f"Error processing Recycle Bin data: {e}")  

    try:  
        results['AmCache_Data'] = process_amcache(directory)  
    except Exception as e:  
        error_messages.append(f"Error processing AmCache data: {e}")  

    try:  
        results['Prefetch Files Details'] = process_prefetch(directory)  
    except Exception as e:  
        error_messages.append(f"Error processing Prefetch files: {e}")  

    try:  
        results['LNK_Files_Details'] = process_le_cmd(directory)  # Update this function to use LNKFiles.exe  
    except Exception as e:  
        error_messages.append(f"Error processing LNK files: {e}")  

    try:  
        results['PowerShell_History'] = process_powershell_history(directory)  
    except Exception as e:  
        error_messages.append(f"Error processing PowerShell history: {e}")  

    try:  
        results['Scheduled_Tasks'] = process_scheduled_tasks(directory)  
    except Exception as e:  
        error_messages.append(f"Error processing scheduled tasks: {e}")  


    prev_dir = os.getcwd()  
    try:  
        os.chdir("plugins")  
        os.system(f'logs.exe -d "{directory}/Windows/System32/winevt/Logs" --html "../logs.html"')  
    except Exception as e:  
        error_messages.append(f"Error generating logs: {e}")  
    finally:  
        os.chdir(prev_dir)  

    if os.path.exists("logs.html"):  
        results['Log_Analysis'] = "logs.html"  
    else:  
        print_to_sidebar("Warning: logs.html not created.")  

    results_folder = os.path.join(directory, "results")  
    additional_files = [  
        "dns_info.html",  
        "network_info.html",  
        "process_info.html",  
        "recent_files.html",  
        "tcp_connections.html",  
        "user_info.html"  
    ]  
    for file in additional_files:  
        file_path = os.path.join(results_folder, file)  
        if os.path.exists(file_path):  
            with open(file_path, 'r') as f:  
                results[file.replace('.html', '').title().replace('_', ' ')] = f.read()  
        else:  
            print_to_sidebar(f"Warning: {file} does not exist in the results folder.")  

    if error_messages:  
        for error in error_messages:  
            print(error)  
        return None  # Return None if there were any errors  

    create_html_report(results, directory, case_name)  
    return results  

def create_html_report(results, directory, case_name):  
    # Check if results is valid  
    if results is None or not isinstance(results, dict):  
        print_to_sidebar("Warning: Results are None or not properly formatted.")  
        return  # Prevent further processing  

    report_file = f"{case_name}.html"  
    additional_files = [  
        "dns_info.html",  
        "network_info.html",  
        "process_info.html",  
        "recent_files.html",  
        "tcp_connections.html",  
        "user_info.html"  
    ]  

    cases_folder = "Cases" 

    # Check if "Cases" directory exists, if not, create it
    if not os.path.exists(cases_folder):
        os.makedirs(cases_folder)

    # Define the report file path
    report_file = os.path.join(cases_folder, f"{case_name}.html")

    # Save the report
    with open(report_file, "w") as file:  
        file.write("""  
        <html>  
        <head>  
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">  
            <title>Analysis Report</title>  
            <style>  
                body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; margin: 0; padding: 0; background-color: #f9f9f9; color: #333; }  
                h1 { text-align: center; color: #444; padding-top: 20px; font-size: 36px; }  
                h2, h3 { color: #555; }  
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }  
                table, th, td { border: 1px solid #ddd; }  
                th, td { padding: 8px; text-align: left; }  
                th { background-color: #7297f7; color: black; }  
                .container { display: flex; min-height: 100vh; }  
                .sidebar { width: 200px; position: fixed; left: 0; top: 0; bottom: 0; background-color: #333; color: white; padding: 20px; padding-top: 60px; overflow-y: auto; border-right: 2px solid #ddd; transition: margin-left 0.3s; z-index: 10; }  
                .sidebar.hidden { margin-left: -200px; }  
                .sidebar-item {  
                    display: flex;  
                    align-items: center;  
                    color: #fff;   
                    text-decoration: none;   
                    padding: 10px;   
                    margin: 5px 0;   
                    border-radius: 5px;   
                    transition: background-color 0.3s;   
                }  
                .sidebar-item .sidebar-text {  
                    margin-left: 10px;   
                }  
                .sidebar-item:hover, .sidebar-item.active {  
                    background-color: #555;   
                }  
                .content {  
                    margin-left: 240px; /* Default width when sidebar is open */  
                    padding: 20px;  
                    width: calc(100% - 240px);  
                    transition: margin-left 0.3s;  
                }  
                .content.expanded {  
                    margin-left: 0; /* Collapse margin when sidebar is hidden */  
                    width: 100%; /* Fill the available space */  
                }  
                .section { margin-bottom: 40px; }  
                .hidden { display: none; }  
                .search-container { margin-bottom: 20px; }  
                #search-bar { padding: 10px; width: 200px; font-size: 16px; background-color: transparent; border: 1px solid gray; border-radius: 5px; }  
                #search-bar:focus { background-color: white; outline: none; }  
                .toggle-btn {   
                    cursor: pointer;   
                    background: #333;   
                    color: white;   
                    border: none;   
                    border-radius: 5px;   
                    padding: 10px;   
                    width: 40px;   
                    text-align: center;   
                    position: fixed;   
                    top: 20px;   
                    left: 10px;   
                    z-index: 20;  
                }  
                .toggle-btn:hover { background-color: #555; }  
            </style>  
        </head>  
        <body>  
            <h1>Analysis Results</h1>  
            <button class="toggle-btn" onclick="toggleSidebar()">&#9776;</button>  
            <div class="container">  
                <div class="sidebar">  
                    <div class="search-container">  
                        <input type="text" id="search-bar" placeholder="Search..." onkeyup="searchFunction()" />  
                    </div>  
                    <h3>Sections</h3>  
                    <a href="javascript:void(0)" onclick="showSection('dashboard')" class="sidebar-item"><i class="fas fa-tachometer-alt"></i> <span class="sidebar-text">Dashboard</span></a>  
        """)  

        # Sidebar links for analysis result categories  
        sidebar_links = [  
            "Log_Analysis", "RecycleBin_Data", "PowerShell_History",  
            "AmCache_Data", "Prefetch Files Details", "LNK_Files_Details", "Scheduled_Tasks"  
        ]  

        for key in sidebar_links:  
            file.write(f'<a href="javascript:void(0)" onclick="showSection(\'{key}\')" class="sidebar-item"><i class="fas fa-file-alt"></i> <span class="sidebar-text">{key.replace("_", " ").title()}</span></a>')  

        # Adding sidebar for additional HTML files  
        additional_file_icons = {  
            "dns_info.html": "fas fa-network-wired",  
            "network_info.html": "fas fa-globe",  
            "process_info.html": "fas fa-tasks",  
            "recent_files.html": "fas fa-clock",  
            "tcp_connections.html": "fas fa-plug",  
            "user_info.html": "fas fa-user"  
        }  

        for additional_file in additional_files:  
            icon = additional_file_icons.get(additional_file, "fas fa-file")  
            file.write(f'<a href="javascript:void(0)" onclick="showSection(\'{additional_file.split(".")[0]}\')" class="sidebar-item"><i class="{icon}"></i> <span class="sidebar-text">{additional_file.replace("_", " ").replace(".html", "").title()}</span></a>')  

        file.write("""  
                </div>  
                <div class="content">  
                    <div id="dashboard" class="section">  
                        <h2>Dashboard</h2>  
                        <table>  
                            <thead>  
                                <tr>  
                                    <th>Module</th>  
                                    <th>Status</th>  
                                </tr>  
                            </thead>  
                            <tbody>  
        """)    

        # Populate dashboard with analysis results  
        for key, value in results.items():  
            if key != 'cmd':  
                found = "Not Found"  
                if isinstance(value, pd.DataFrame) and not value.empty:  
                    found = "Found"  
                elif isinstance(value, dict) and any(isinstance(v, pd.DataFrame) and not v.empty for v in value.values()):  
                    found = "Found"  
                elif key == 'Log_Analysis':  
                    found = "Found" if os.path.exists(value) else "Not Found"
                
                file.write(f"""  
                    <tr>  
                        <td>{key.replace('_', ' ').title()}</td>  
                        <td>{found}</td>  
                    </tr>  
                """)                

        file.write('''  
                            </tbody>  
                        </table>  
                    </div>  
        ''')  

        # Separate sections for each key  
        for key, value in results.items():  
            if key != 'cmd':  
                file.write(f'<div id="{key}" class="section hidden">')  
                file.write(f"<h2>{key.replace('_', ' ').title()}</h2>")  

                if isinstance(value, pd.DataFrame) and not value.empty:  
                    file.write(value.to_html(index=False, escape=False))  
                elif isinstance(value, dict):  
                    for user, df in value.items():  
                        file.write(f"<h3>User: {user}</h3>")  
                        if isinstance(df, pd.DataFrame) and not df.empty:  
                            file.write(df.to_html(index=False, escape=False))  
                        else:  
                            file.write("<p>No data available.</p>")  
                elif isinstance(value, list):  
                    file.write("<pre>" + "\n".join(value) + "</pre>")  
                elif value is None:  
                    file.write("<p>No data available.</p>")  

                # Embed logs if present  
                if key == 'Log_Analysis':  
                    logs_file_path = 'logs.html'  
                    if os.path.exists(logs_file_path):  
                        with open(logs_file_path, 'r') as logs_file:  
                            logs_content = logs_file.read()  
                            file.write(logs_content)  
                        os.remove(logs_file_path)  

                file.write("</div>")  

        # Adding separate sections for additional HTML files  
        for additional_file in additional_files:  
            section_name = additional_file.split('.')[0]  # Get section name without the extension  
            file.write(f'<div id="{section_name}" class="section hidden">')  
            file.write(f"<h2>{section_name.replace('_', ' ').title()}</h2>")  

            # Load content from each of the additional HTML files  
            result_file_path = os.path.join(directory, "results", additional_file)  
            print_to_sidebar(f"Checking for additional file: {result_file_path}")  # Debugging output  
            if os.path.exists(result_file_path):  
                with open(result_file_path, 'r') as result_file:  
                    result_content = result_file.read()  
                    file.write(result_content)  
            else:  
                file.write("<p>No data available for this section.</p>")  

            file.write("</div>")  # End of additional file section  

        # Close the sidebar and prepare for JavaScript  
        file.write("""  
            </div>  <!-- End of content -->  
            </div>  <!-- End of container -->  
            <script>  
                function toggleSidebar() {  
                    var sidebar = document.querySelector('.sidebar');  
                    var content = document.querySelector('.content');  
                    sidebar.classList.toggle('hidden');  
                    content.classList.toggle('expanded'); // Adjust content size  
                }  
                function showSection(section) {  
                    var sections = document.querySelectorAll('.section');  
                    sections.forEach(function(sec) {  
                        sec.classList.add('hidden');  
                    });  

                    var items = document.querySelectorAll('.sidebar-item');  
                    items.forEach(function(item) {  
                        item.classList.remove('active');  
                    });  

                    document.getElementById(section).classList.remove('hidden');  
                    var activeItem = document.querySelector(`.sidebar-item[onclick*='${section}']`);  
                    if (activeItem) {  
                        activeItem.classList.add('active');  
                    }  
                }  
                window.onload = function() {  
                    showSection('dashboard');  
                };  

                function searchFunction() {  
                    var input, filter, rows, cells, i, txtValue;  
                    input = document.getElementById('search-bar');  
                    filter = input.value.toLowerCase();  
                    var visibleSection = document.querySelector('.section:not(.hidden)');  
                    if (!visibleSection) return;  

                    rows = visibleSection.querySelectorAll('table tbody tr');  
                    rows.forEach(function(row) {  
                        cells = row.querySelectorAll('td');  
                        let rowVisible = false;  

                        cells.forEach(function(cell) {  
                            txtValue = cell.textContent || cell.innerText;  
                            if (txtValue.toLowerCase().indexOf(filter) > -1) {  
                                rowVisible = true;  
                            }  
                        });  

                        row.style.display = rowVisible ? '' : 'none';  
                    });  
                }  
            </script>  
        """)  

    print_to_sidebar(f"HTML report created: {report_file}") 
    print_to_sidebar(f"Analysis completed. Click View Report Button to View Results") 

    
    # Delete the entire "plugins" directory after analysis  
    plugin_directory = "plugins"  
    if os.path.exists(plugin_directory):  
        import shutil  
        shutil.rmtree(plugin_directory)  

    # Delete the output directory after analysis  
    output_directory = "output"  
    if os.path.exists(output_directory):  
        import shutil  
        shutil.rmtree(output_directory) 


def view_report():
    case_name = case_name_entry.get().strip()  # Get case name from entry field
    if not case_name:
        status_label.config(text="Please enter a case name.")
        return

    report_file = os.path.join("Cases", f"{case_name}.html")  # Construct the correct path

    if os.path.exists(report_file):
        webview.create_window('Analysis Report', f'file://{os.path.abspath(report_file)}')
        webview.start()
    else:
        status_label.config(text="Report not found.")

def print_to_sidebar(text):
    cmd_output_text.insert(tk.END, text + '\n')
    cmd_output_text.yview(tk.END)  # Ensure the view scrolls to the bottom
    cmd_output_text.update_idletasks()  # Update the text widget


def populate_case_list():
    cases_folder = "Cases"
    if os.path.exists(cases_folder):
        case_files = [f[:-5] for f in os.listdir(cases_folder) if f.endswith(".html")]
        case_listbox.delete(0, tk.END)  # Clear current list
        for case in case_files:
            case_listbox.insert(tk.END, case)

def open_selected_case_from_list():
    selected_case = case_listbox.get(tk.ACTIVE)  # Get selected case name
    if selected_case:
        case_file = os.path.join("Cases", f"{selected_case}.html")
        if os.path.exists(case_file):
            webview.create_window(f'Case Report - {selected_case}', f'file://{os.path.abspath(case_file)}')
            webview.start()
        else:
            print_to_sidebar("Error: Case file not found.")
    else:
        print_to_sidebar("No case selected.")

# Function to handle case open debug
def open_case_report(case_name):
    case_file = os.path.join("Cases", f"{case_name}.html")
    if os.path.exists(case_file):
        try:
            webview.create_window(f'Case Report - {case_name}', f'file://{os.path.abspath(case_file)}')
            webview.start()
        except Exception as e:
            print_to_sidebar(f"Error opening case report: {e}")
    else:
        print_to_sidebar("Error: Case file not found.")
        
create_gui()